﻿namespace jwt_Assignment_ex.Models
{
    public class Role
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
