import postuser from "./postuser"
export default postuser;
