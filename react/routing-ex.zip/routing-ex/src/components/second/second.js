import React, {Component} from 'react';
import Menu from '../menu/menu';

const Second = () => {
  return (
    <div>
      <Menu />
      <p>This is my second component Thank you all..</p>
    </div>
  )
}

export default Second;