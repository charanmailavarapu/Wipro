import React, {Component} from 'react';

const First = () => {
  return (
    <div>
      <p>
        This is my first component!
      </p>
    </div>
  )
}

export default First;