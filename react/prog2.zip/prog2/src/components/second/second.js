import React, {Component} from 'react';

const Second = () => {
  return (
    <div>
      <p>This is my second component Thank you all..</p>
    </div>
  )
}

export default Second;