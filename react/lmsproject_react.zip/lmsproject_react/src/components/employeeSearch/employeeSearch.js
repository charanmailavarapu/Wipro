import React, {Component} from 'react';
import './employeeSearch.scss'

export default class employeeSearch extends Component {
  render() {
    return <div className="component-employee-search">Hello! component employeeSearch</div>
  }
}

