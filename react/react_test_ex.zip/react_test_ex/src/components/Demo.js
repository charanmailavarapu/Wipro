const Demo = () => {

    const sayHello= () => {
        return "Welcome to react testing";
    }

    return (
        <div>
            {sayHello()}
        </div>
    )
}

export default Demo;